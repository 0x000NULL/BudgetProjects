module.exports = {
 home: 'Home Page',
 notFound: '404 Not Found'
};